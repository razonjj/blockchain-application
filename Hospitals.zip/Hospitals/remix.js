if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);
} 
else {
  web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8545"));
}

web3.eth.defaultAccount = web3.eth.accounts[0];

var BloodBankContract = web3.eth.contract([
	{
		"constant": false,
		"inputs": [
			{
				"name": "_bloodType",
				"type": "string"
			},
			{
				"name": "_bloodCount",
				"type": "int256"
			}
		],
		"name": "addCount",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "a",
				"type": "int256"
			},
			{
				"name": "ab",
				"type": "int256"
			},
			{
				"name": "b",
				"type": "int256"
			},
			{
				"name": "o",
				"type": "int256"
			},
			{
				"name": "a_",
				"type": "int256"
			},
			{
				"name": "ab_",
				"type": "int256"
			},
			{
				"name": "b_",
				"type": "int256"
			},
			{
				"name": "o_",
				"type": "int256"
			}
		],
		"name": "approveReq",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCountA",
		"outputs": [
			{
				"name": "",
				"type": "string"
			},
			{
				"name": "",
				"type": "int256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCountA_",
		"outputs": [
			{
				"name": "",
				"type": "string"
			},
			{
				"name": "",
				"type": "int256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCountAB",
		"outputs": [
			{
				"name": "",
				"type": "string"
			},
			{
				"name": "",
				"type": "int256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCountAB_",
		"outputs": [
			{
				"name": "",
				"type": "string"
			},
			{
				"name": "",
				"type": "int256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCountB",
		"outputs": [
			{
				"name": "",
				"type": "string"
			},
			{
				"name": "",
				"type": "int256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCountB_",
		"outputs": [
			{
				"name": "",
				"type": "string"
			},
			{
				"name": "",
				"type": "int256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCountO",
		"outputs": [
			{
				"name": "",
				"type": "string"
			},
			{
				"name": "",
				"type": "int256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getCountO_",
		"outputs": [
			{
				"name": "",
				"type": "string"
			},
			{
				"name": "",
				"type": "int256"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	}
]);

var BloodBank = BloodBankContract.at('0xe1c7845b6E943Febc8CF4E971d1B458a97ddDc24');

BloodBank.getCountA(function(error, result) {
    if (!error) {
        a=result[0];
        b=result[1];
		$("#num_BagsA").html(''+b);
		$("#quantity1").html(''+b);
    } 
    else{
        console.log(error);
    }
});

BloodBank.getCountB(function(error, result) {
    if (!error) {
        a=result[0];
        b=result[1];
		$("#num_BagsB").html(''+b);
		$("#quantity3").html(''+b);
    } 
    else{
        console.log(error);
    }
});

BloodBank.getCountAB(function(error, result) {
    if (!error) {
        a=result[0];
        b=result[1];
		$("#num_BagsAB").html(''+b);
		$("#quantity2").html(''+b);
    } 
    else{
        console.log(error);
    }
});

BloodBank.getCountO(function(error, result) {
    if (!error) {
        a=result[0];
        b=result[1];
		$("#num_BagsO").html(''+b);
		$("#quantity4").html(''+b);
    } 
    else{
        console.log(error);
    }
});

BloodBank.getCountA_(function(error, result) {
    if (!error) {
        a=result[0];
        b=result[1];
		$("#num_BagsA_").html(''+b);
		$("#quantity5").html(''+b);
    } 
    else{
        console.log(error);
    }
});

BloodBank.getCountB_(function(error, result) {
    if (!error) {
        a=result[0];
        b=result[1];
		$("#num_BagsB_").html(''+b);
		$("#quantity7").html(''+b);
    } 
    else{
        console.log(error);
    }
});

BloodBank.getCountAB_(function(error, result) {
    if (!error) {
        a=result[0];
        b=result[1];
		$("#num_BagsAB_").html(''+b);
		$("#quantity6").html(''+b);
    } 
    else{
        console.log(error);
    }
});

BloodBank.getCountO_(function(error, result) {
    if (!error) {
        a=result[0];
        b=result[1];
		$("#num_BagsO_").html(''+b);
		$("#quantity8").html(''+b);
    } 
    else{
        console.log(error);
    }
});

$("#add_bagAbut").click(function(e) {
	$("#loader").show();
	BloodBank.addCount("typeA",$("#add_bagA").val());
	BloodBank.getCountA(function(error, result) {
		if (!error) {
			a=result[0];
			b=result[1];
			$("#num_BagsA").html(''+b);
		} 
		else{
				console.log(error);
		}
		
	});
});

$("#add_bagBbut").click(function(e) {
	$("#loader").show();
	BloodBank.addCount("typeB",$("#add_bagB").val());
	BloodBank.getCountB(function(error, result) {
		if (!error) {
			a=result[0];
			b=result[1];
			$("#num_BagsB").html(''+b);
		} 
		else{
				console.log(error);
		}
		
	});
});

$("#add_bagABbut").click(function(e) {
	$("#loader").show();
	BloodBank.addCount("typeAB",$("#add_bagAB").val());
	BloodBank.getCountAB(function(error, result) {
		if (!error) {
			a=result[0];
			b=result[1];
			$("#num_BagsAB").html(''+b);
		} 
		else{
				console.log(error);
		}
		
	});
});

$("#add_bagObut").click(function(e) {
	$("#loader").show();
	BloodBank.addCount("typeO",$("#add_bagO").val());
	BloodBank.getCountO(function(error, result) {
		if (!error) {
			a=result[0];
			b=result[1];
			$("#num_BagsO").html(''+b);
		} 
		else{
				console.log(error);
		}
		
	});
});

$("#add_bagA_but").click(function(e) {
	$("#loader").show();
	BloodBank.addCount("typeA_",$("#add_bagA_").val());
	BloodBank.getCountA_(function(error, result) {
		if (!error) {
			a=result[0];
			b=result[1];
			$("#num_BagsA_").html(''+b);
		} 
		else{
				console.log(error);
		}
		
	});
});

$("#add_bagB_but").click(function(e) {
	$("#loader").show();
	BloodBank.addCount("typeB_",$("#add_bagB_").val());
	BloodBank.getCountB_(function(error, result) {
		if (!error) {
			a=result[0];
			b=result[1];
			$("#num_BagsB_").html(''+b);
		} 
		else{
				console.log(error);
		}
		
	});
});

$("#add_bagAB_but").click(function(e) {
	$("#loader").show();
	BloodBank.addCount("typeAB_",$("#add_bagAB_").val());
	BloodBank.getCountAB_(function(error, result) {
		if (!error) {
			a=result[0];
			b=result[1];
			$("#num_BagsAB_").html(''+b);
		} 
		else{
				console.log(error);
		}
		
	});
});

$("#add_bagO_but").click(function(e) {
	$("#loader").show();
	BloodBank.addCount("typeO_",$("#add_bagO_").val());
	BloodBank.getCountO_(function(error, result) {
		if (!error) {
			a=result[0];
			b=result[1];
			$("#num_BagsO_").html(''+b);
		} 
		else{
				console.log(error);
		}
		
	});
});

$("#button").click(function(e) {
	$("#loader").show();

	var valid = this.form.checkValidity();
		 if(valid){
			 
			 var type_a_pos 	= $('#type_a_pos').val();
			 var type_b_pos		= $('#type_b_pos').val();
			 var type_ab_pos 	= $('#type_ab_pos').val();
			 var type_o_pos		= $('#type_o_pos').val();
			 var type_a_neg 	= $('#type_a_neg').val();
			 var type_b_neg		= $('#type_b_neg').val();
			 var type_ab_neg 	= $('#type_ab_neg').val();
			 var type_o_neg		= $('#type_o_neg').val();
			 
			 e.preventDefault();
			 
			 $.ajax({
				 type: 'POST',
				 url: 'addtodb.php',
				 data:{type_a_pos:type_a_pos, type_b_pos:type_b_pos, type_ab_pos:type_ab_pos,type_o_pos:type_o_pos,type_a_neg:type_a_neg,type_b_neg:type_b_neg,type_ab_neg:type_ab_neg,type_o_neg:type_o_neg},
				 success:function(data){
					 Swal.fire({
						 'title': 'Success!',
						 'text': data,
						 'type': 'success'
					 })
					 //setTimeout('window.location.href="index.php"',2000);
				 },
				 erros:function(data){
					 Swal.fire({
						 'title': 'Error',
						 'text': 'There were errors while saving the data',
						 'type': 'error'
					 })
				 }
			 });
			 
		 }
		 else{
			 
		 }
});