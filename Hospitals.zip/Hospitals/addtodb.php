<?php
	require_once('../config.php');
	
?>
<?php

if(isset($_POST)){
    $type_o_pos 			= $_POST['type_o_pos'];
    $type_a_pos 			= $_POST['type_a_pos'];
    $type_ab_pos 			= $_POST['type_ab_pos'];
    $type_b_pos 			= $_POST['type_b_pos'];
    $type_o_neg 			= $_POST['type_o_neg'];
    $type_a_neg 			= $_POST['type_a_neg'];
    $type_ab_neg 			= $_POST['type_ab_neg'];
    $type_b_neg 			= $_POST['type_b_neg'];


    $sql="INSERT INTO pending(A,B,AB,O,A_Negative,B_Negative,AB_Negative,O_Negative) VALUES(?,?,?,?,?,?,?,?)";
    $stminsert = $db->prepare($sql);
    $result=$stminsert->execute([$type_a_pos, $type_b_pos,$type_ab_pos,$type_o_pos,$type_a_neg,$type_b_neg,$type_ab_neg,$type_o_neg]);

    if($result){
        echo 'Successfully Saved';
    }
    else{
        echo 'There were errors while saving the data';
    }
}
else{
    echo 'No data';
}