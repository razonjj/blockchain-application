<?php
	require('../config.php');
?>
<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Philippine Red Cross - Blood Bank</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
		<link rel="stylesheet" type="text/css" href="custom.css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Raleway:500&display=swap" rel="stylesheet">
		<script src="../node_modules/web3/dist/web3.min.js"></script>
	</head>
	<body>
		<!-- Requests -->
		<div class="modal" id="requests">
			<div class="modal-dialog">
				<div class="modal-content">
					<!-- Modal Header -->
					<div class="modal-header">
					  <h4 class="modal-title">Send Request</h4> 
					</div>
					<!-- Modal body -->
					<div class="modal-body">
						<form>
						  <div class="form-group row">
							<label for="reqId" class="col-sm-4 col-form-label mr-2">Request ID#:</label>
							<div class="col-sm-5 mt-2">
								<?php
									$query="SELECT * FROM pending ORDER BY req_id DESC LIMIT 1";
									$result=mysqli_query($con,$query);
									$query1="SELECT * FROM approved ORDER BY req_id DESC LIMIT 1";
									$result1=mysqli_query($con,$query1);
									if($result)
									while($row = $result-> fetch_assoc()){
								?>
							  <input type="text" readonly class="form-control-plaintext" id="reqId" value="<?php echo $row["req_id"]+1;?>">
							  <?php
									}
									else
									while($row = $result1-> fetch_assoc()){?>
								<input type="text" readonly class="form-control-plaintext" id="reqId" value="<?php echo $row["req_id"]+1;?>">
								<?php	}?> 
							</div>
						  </div>
						  <div class="form-group row">
							<label for="userReq" class="col-sm-4 col-form-label mr-2">Requested by:</label>
							<div class="col-sm-5 mt-2">
							  <input type="text" class="form-control" id="userReq" value="Vince">
							</div>
						  </div>
						  <div class="form-group row">
							<label for="bloodBank" class="col-sm-4 col-form-label mr-2">Blood Bank:</label>
							<div class="col-sm-5 mt-2">
							  <input type="text" class="form-control" id="bloodBank" value="Red Cross Makati">
							</div>
						  </div>
						</form>
						<br>
						<table class="table table-striped">
							  <thead>
								  <tr>
									  <th scope="col">Blood Types</th>
									  <th scope="col"></th>
									  <th scope="col">Available Units</th>
									</tr>
							  </thead>
							<tr><form method="post">
								<td>Type O</td>
								<td><input type="number" name="type_o_pos" id="type_o_pos"></td>
								<td id="quantity4"></td>
							</tr>
							<tr>
								<td>Type A</td>
								<td><input type="number" name="type_a_pos" id="type_a_pos"></td>
								<td id="quantity1"></td>
							</tr>
							<tr>
								<td>Type B</td>
								<td><input type="number" name="type_b_pos" id="type_b_pos"></td>
								<td id="quantity3"></td>
							</tr>
							<tr>
								<td>Type AB</td>
								<td><input type="number" name="type_ab_pos" id="type_ab_pos"></td>
								<td id="quantity2"></td>
							</tr>
							<tr>
								<td>Type O-</td>
								<td><input type="number" name="type_o_neg" id="type_o_neg"></td>
								<td id="quantity8"></td>
							</tr>
							<tr>
								<td>Type A-</td>
								<td><input type="number" name="type_a_neg" id="type_a_neg"></td>
								<td id="quantity5"></td>
							</tr>
							<tr>
								<td>Type B-</td>
								<td><input type="number" name="type_b_neg" id="type_b_neg"></td>
								<td id="quantity7"></td>
							</tr>
							<tr>
								<td>Type AB-</td>
								<td><input type="number" name="type_ab_neg" id="type_ab_neg"></td>
								<td id="quantity6"></td>
									</tr>
						</table>
					</div>
					<!-- Modal footer -->
					<div class="modal-footer">
					  <button type="submit" class="btn btn-danger" data-dismiss="modal" value="Submit" id="button">Submit</button>
					  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button></form>
					</div>
				</div>
			</div>
		</div>
		<!-- Inventory -->
				<div class="modal" id="inv">
				    <div class="modal-dialog">
				      	<div class="modal-content">
				        	<!-- Modal Header -->
				        	<div class="modal-header">
				          <h4 class="modal-title">Inventory</h4>
				        </div> 
				        <!-- Modal body -->
				        <div class="modal-body">
				          <table class="table table-striped">
						 <thead>
							  <tr>
								  <th scope="col">Blood Types</th>
								  <th scope="col">Number of Bags Available</th>
								</tr>
						  </thead>
							<tr>
								<td>Type A</td>
								<td id="num_BagsA"></td>
							</tr>
							<tr>
								<td>Type AB</td>
								<td id="num_BagsAB"></td>
							</tr>
							<tr>
								<td>Type B</td>
								<td id="num_BagsB"></td>
							</tr>
							<tr>
								<td>Type O</td>
								<td id="num_BagsO"></td>
							</tr>
							<tr>
								<td>Type A-</td>
								<td id="num_BagsA_"></td>
							</tr>
							<tr>
								<td>Type AB-</td>
								<td id="num_BagsAB_"></td>
							</tr>
							<tr>
								<td>Type B-</td>
								<td id="num_BagsB_"></td>
							</tr>
							<tr>
								<td>Type O-</td>
								<td id="num_BagsO_"></td>
							</tr>
						  </table>
				        </div>
				        <!-- Modal footer -->
				        <div class="modal-footer">
				          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				        </div>
				        
				      </div>
				    </div>
				  </div>
		<!-- Transaction History -->
			  <div class="modal" id="trans">
			    <div class="modal-dialog">
			      <div class="modal-content">
				        <!-- Modal Header -->
				        <div class="modal-header">
				          <h4 class="modal-title">Transaction History</h4>
				        </div>
				        <!-- Modal body -->
				        <div class="modal-body">
				          <table class="table table-striped table-borderless">
							  <thead>
								<tr>
								  <th scope="col">Request ID</th>
								  <th scope="col">Blood Bank</th>
								  <th scope="col">Date Requested</th>
								  <th scope="col">Status</th>
								  <th scope="col"></th>
								</tr>
							</thead>
							  <tbody>
								<tr>
								  <td id="reqId"></td>
								  <td id="blood_bank"></td>
								  <td id="date_req"></td>
								  <td id="req_status"></td>
								  <td><button type="button" class="btn btn-danger" data-toggle="modal" data-dismiss="modal" data-target="#viewDetails" id="details">View Details</button></td>
								</tr>
							  </tbody>
							</table>
				        </div>
				        <!-- Modal footer -->
				        <div class="modal-footer">
				          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				        </div>
			      	</div>
			    </div>
			  </div>
			  <!--View Details-->
					<div class="modal" id="viewDetails">
				<div class="modal-dialog">
					<div class="modal-content">
						<!-- Modal Header -->
						<div class="modal-header">
						  <h4 class="modal-title">View Details</h4> 
						</div>
						<!-- Modal body -->
						<div class="modal-body">
							<form>
							  <div class="form-group row">
								<label for="reqId" class="col-sm-5 col-form-label mr-2">Request ID#:</label>
								<div class="col-sm-5 mb-3">
								  <input type="text" readonly class="form-control-plaintext" id="reqId" value="">
								</div>
							  </div>
							  <div class="form-group row">
								<label for="userReq" class="col-sm-5 col-form-label mr-2">Requested by:</label>
								<div class="col-sm-5 mb-3">
								  <input type="text" readonly class="form-control-plaintext" id="userReq">
								</div>
							  </div>
							  <div class="form-group row">
								<label for="bloodBank" class="col-sm-5 col-form-label mr-2">Blood Bank:</label>
								<div class="col-sm-5 mb-3">
								  <input type="text" readonly class="form-control-plaintext" id="bloodBank">
								</div>
							  </div>
							</form>
							<br>
							<table>
								<th>Requested Blood Types</th>
								<th>Requested Number of Bags</th>
								<th>Quantity</th>
								<tr>
									<td id="reqBloodType"></td>
									<td id="reqNumBags"></td>
									<td id="quantity"></td>
								</tr>
							</table>
						</div>
						<!-- Modal footer -->
						<div class="modal-footer">
						  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
						</div>
					</div>
				</div>
			</div>
		<!--Navigation-->
		<nav class="navbar navbar-light bg-light">
		  <a class="navbar-brand" href="#">
		    <img src="prc_logo.png" width="100" height="100" alt="">
			<h1>Philippine Red Cross</h1>
			</a>
			<ul class="navbar-nav">
		      <li class="nav-item active">
		        <a class="nav-link" href="#">Logout <span class="sr-only">(current)</span></a>
		      </li>
		    </ul>
		</nav>
		<br>
		<div class="page2">
			<div class="row row1">
				<div class="col col1">
					<div class="row row11">
						<div class="col">
				  			<button type="button" class="btn btn-lg btn_size" data-toggle="modal" data-target="#requests" id="req"><img src="send.png" id="reqLogo" >&nbsp Send Request</button>
						</div>
						<div class="col">
				  			<button type="button" class="btn btn-lg btn_size" data-toggle="modal" data-target="#inv" id="inv"><img src="inventory.png" id="invLogo" >&nbsp &nbsp  Inventory</button>
						</div>
					</div>
					<div class="row 22">
						<div class="col">
				  			<button type="button" class="btn btn-lg btn_size" data-toggle="modal" data-target="#trans" id="trans"><img src="his.png" id="hisLogo" > &nbsp Transaction History</button>
						</div>
					</div>
				</div>
					<div class="col"><br><br>
						<table class="table table-stripped table-borderless" id="rLog">
					  		<thead>
								<tr>
								  <th scope="col">REQUEST LOG</th>
								  <th scope="col"></th>
								  <th scope="col"></th>
								</tr>
							</thead>
					  		<thead>
								<tr>
								  <th scope="col">Number of Bags</th>
								  <th scope="col">Blood Type</th>
								  <th scope="col">Date Requested</th>
								</tr>
							</thead>
							<tbody>
								<tr>
								  <td></td>
								  <td>A</td>
								  <td>06/20/2020</td>
								</tr>
								<tr>
								  <td></td>
								  <td>O</td>
								  <td>06/20/2020</td>
								</tr>
								<tr>
								  <td></td>
								  <td>AB</td>
								  <td>06/20/2020</td>
								</tr>
								<tr>
								  <td></td>
								  <td>B</td>
								  <td>06/20/2020</td>
								</tr>
								<tr>
								  <td></td>
								  <td>A-</td>
								  <td>06/20/2020</td>
								</tr>
								<tr>
								  <td></td>
								  <td>O-</td>
								  <td>06/20/2020</td>
								</tr>
								<tr>
								  <td></td>
								  <td>AB-</td>
								  <td>06/20/2020</td>
								</tr>
								<tr>
								  <td></td>
								  <td>B-</td>
								  <td>06/20/2020</td>
								</tr>
								<tr id="reqStat">
								  <td>Request ID:</td>
								  <td id="reqId"></td>
								  <td>Status: Pending</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script> 
			<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
			<script src="remix.js"></script>
			<script>
				function myFunction() {
				  alert("The request was submitted successfully!");
				}
			</script>
	</body>
</html>
