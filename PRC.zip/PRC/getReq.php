<?php
require("config.php");

function getUserData($id){
	$array = array();
	$q = mysql_query("SELECT * FROM pending WHERE req_id=".$id);
	while($r=mysql_fetch_assoc($q)){
		$array['req_id'] = $r['req_id'];
		$array['A'] = $r['A'];
		$array['B'] = $r['B'];
		$array['AB'] = $r['AB'];
		$array['O'] = $r['O'];
		$array['A-'] = $r['A-'];
		$array['B-'] = $r['B-'];
		$array['AB-'] = $r['AB-'];
		$array['O-'] = $r['O-'];
	}
	return $array;
}

function getId($username){
	$q = mysql_query("SELECT * FROM pending WHERE req_id=".$username);
	while($r=mysql_fetch_assoc($q)){
		return $r['i'];
	}
}