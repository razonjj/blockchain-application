<?php
	require('../config.php');
?>

<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Philippine Red Cross - Blood Bank</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
		<link rel="stylesheet" type="text/css" href="custom.css">
		<link href="https://fonts.googleapis.com/css?family=Montserrat&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Raleway:500&display=swap" rel="stylesheet">
		<script src="https://kit.fontawesome.com/a076d05399.js"></script>
		<script src="../node_modules/web3/dist/web3.min.js"></script>
	</head>
	<body>
		<!--Navigation-->
		<nav class="navbar navbar-light bg-light">
		  <a class="navbar-brand" href="#">
		    <img src="prc_logo.png" width="100" height="100" alt="">
			<h1>Philippine Red Cross</h1>
			</a>
			<ul class="navbar-nav">
		      <li class="nav-item active">
		        <a class="nav-link" href="login.html">Logout <span class="sr-only">(current)</span></a>
		      </li>
		    </ul>
		</nav>
		<div class="container">
			<!-- Requests -->
			<div class="modal" id="requests">
			    <div class="modal-dialog">
			      	<div class="modal-content">
				        <!-- Modal Header -->
				        <div class="modal-header">
				          <h4 class="modal-title">View Request</h4>
				        </div>
				        <!-- Modal body -->
				        <div class="modal-body">
							<input class="form-control" type="text" placeholder="Search" aria-label="Search">
				          <table class="table table-striped">
						  <thead>
							  <tr>
								  <th scope="col">Request ID</th>
								  <th scope="col">Blood Bank</th>
								  <th scope="col">Description</th>
								  <th scope="col"></th>
								</tr>
						  </thead>
							<tr>
								<td id="reqId"></td>
								<td id="blood_bank"></td>
								<td id="description"></td>
								<td><button type="button" class="btn btn-danger" data-toggle="modal" data-dismiss="modal" data-target="#viewRequests" id="viewReq">View Request</button></td>
							</tr>
						  </table>
				        </div>
				        <!-- Modal footer -->
				        <div class="modal-footer">
						  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				        </div>
			      	</div>
			    </div>
			</div>
			<!-- Inventory -->
			<div class="modal" id="inv">
			    <div class="modal-dialog">
			      	<div class="modal-content">
			        	<!-- Modal Header -->
			        	<div class="modal-header">
			          <h4 class="modal-title">Inventory</h4>
			        </div> 
			        <!-- Modal body -->
			        <div class="modal-body">
			          <table class="table table-striped">
					 <thead>
						  <tr>
							  <th scope="col">Blood Types</th>
							  <th scope="col">Number of Bags Available</th>
							  <th scope="col"></th>
							  <th scope="col"></th>
							</tr>
					  </thead>
						<tr>
							<td>Type A</td>
							<td id="num_BagsA"></td>
							<td><input class="form-control form-control-sm" type="number" placeholder="0" id="add_bagA"></td>
							<td><button type="button" class="btn btn-info" id="add_bagAbut"><i class="fas fa-plus-circle"></i></button></td>
						</tr>
						<tr>
							<td>Type AB</td>
							<td id="num_BagsAB"></td>
							<td><input class="form-control form-control-sm" type="number" placeholder="0" id="add_bagAB"></td>
							<td><button type="button" class="btn btn-info" id="add_bagABbut"><i class="fas fa-plus-circle"></i></button></td>
						</tr>
						<tr>
							<td>Type B</td>
							<td id="num_BagsB"></td>
							<td><input class="form-control form-control-sm" type="number" placeholder="0" id="add_bagB"></td>
							<td><button type="button" class="btn btn-info" id="add_bagBbut"><i class="fas fa-plus-circle"></i></button></td>
						</tr>
						<tr>
							<td>Type O</td>
							<td id="num_BagsO"></td>
							<td><input class="form-control form-control-sm" type="number" placeholder="0" id="add_bagO"></td>
							<td><button type="button" class="btn btn-info" id="add_bagObut"><i class="fas fa-plus-circle"></i></button></td>
						</tr>
						<tr>
							<td>Type A-</td>
							<td id="num_BagsA_"></td>
							<td><input class="form-control form-control-sm" type="number" placeholder="0" id="add_bagA_"></td>
							<td><button type="button" class="btn btn-info" id="add_bagA_but"><i class="fas fa-plus-circle"></i></button></td>
						</tr>
						<tr>
							<td>Type AB-</td>
							<td id="num_BagsAB_"></td>
							<td><input class="form-control form-control-sm" type="number" placeholder="0" id="add_bagAB_"></td>
							<td><button type="button" class="btn btn-info" id="add_bagAB_but"><i class="fas fa-plus-circle"></i></button></td>
						</tr>
						<tr>
							<td>Type B-</td>
							<td id="num_BagsB_"></td>
							<td><input class="form-control form-control-sm" type="number" placeholder="0" id="add_bagB_"></td>
							<td><button type="button" class="btn btn-info" id="add_bagB_but"><i class="fas fa-plus-circle"></i></button></td>
						</tr>
						<tr>
							<td>Type O-</td>
							<td id="num_BagsO_"></td>
							<td><input class="form-control form-control-sm" type="number" placeholder="0" id="add_bagO_"></td>
							<td><button type="button" class="btn btn-info" id="add_bagO_but"><i class="fas fa-plus-circle"></i></button></td>
						</tr>
					  </table>
			        </div>
			        <!-- Modal footer -->
			        <div class="modal-footer">
			          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
			        </div>
			      </div>
			    </div>
			  </div>
			  <!-- Transaction History -->
			  <div class="modal" id="trans">
			    <div class="modal-dialog">
			      <div class="modal-content">
				        <!-- Modal Header -->
				        <div class="modal-header">
				          <h4 class="modal-title">Transaction History</h4>
				        </div>
				        <!-- Modal body -->
						<div class="modal-body">
				          <table class="table table-striped table-borderless">
							  <thead>
								<tr>
								  <th scope="col">Request ID</th>
								  <th scope="col">Blood Bank</th>
								  <th scope="col">Blood Type</th>
								  <th scope="col">Date Requested</th>
								  <th scope="col">Status</th>
								</tr>
							</thead>
							  <tbody>
								<tr>
								  <td id="reqId"></td>
								  <td id="blood_bank"></td>
								  <td id="blood_type"></td>
								  <td id="date_req"></td>
								  <td id="req_status"></td>
								</tr>
							  </tbody>
							</table>
				        </div>
				        <!-- Modal footer -->
				        <div class="modal-footer">
				          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
				        </div>
			      	</div>
			    </div>
			  </div>
				<!--View Request-->
					<div class="modal" id="viewRequests">
				<div class="modal-dialog">
					<div class="modal-content">
						<!-- Modal Header -->
						<div class="modal-header">
						  <h4 class="modal-title">View Requests</h4> 
						</div>
						<?php
							$query="SELECT * FROM pending LIMIT 1";
							$result=mysqli_query($con,$query);
						?>
						<!-- Modal body -->
						<div class="modal-body">
							<form>
							  <div class="form-group row">
								<label for="reqId" class="col-sm-5 col-form-label mr-2">Request ID#:</label>
								<div class="col-sm-5 mb-3">
								  <input type="text" readonly class="form-control-plaintext" id="reqId" value="01">
								</div>
							  </div>
							  <div class="form-group row">
								<label for="userReq" class="col-sm-5 col-form-label mr-2">Requested by:</label>
								<div class="col-sm-5 mb-3">
								  <input type="text" readonly class="form-control-plaintext" id="userReq">
								</div>
							  </div>
							  <div class="form-group row">
								<label for="bloodBank" class="col-sm-5 col-form-label mr-2">Blood Bank:</label>
								<div class="col-sm-5 mb-3">
								  <input type="text" readonly class="form-control-plaintext" id="bloodBank">
								</div>
							  </div>
							</form>
							<br>
							<table>
								<th>Requested Blood Types</th>
								<th>Requested Number of Bags</th>
								<th>Quantity</th>
								<tr>
								<?php
								if( $result ){
									$i=0;
									while($row = mysqli_fetch_assoc($result)) {   
										foreach ($row as $col => $val) {
											if($i>0){
								?>			
												<tr>
												<td id="reqBloodType<?php echo $i?>"><?php echo $col; ?></td>
												<td id="reqNumBags<?php echo $i?>"><?php echo $val; ?></td>
												<td id="quantity<?php echo $i?>"></td><tr>
											}
								<?php
											$i++;
										}
									}
								}
								else{
									
								}
								?>
									<td id="reqBloodType"></td>
									<td id="reqNumBags"></td>
									<td id="quantity"></td>
								</tr>
							</table>
						</div>
						<!-- Modal footer -->
						<div class="modal-footer">
						  <button type="submit" class="btn btn-success" data-dismiss="modal"  onclick="myFunction()">Approve</button>
						  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
						</div>
					</div>
				</div>
			</div>
			<!---->
			<br>
			<div class="page2">
				<div class="row">
					<div class="col">
					 	<button type="button" class="btn btn-lg btn_size" data-toggle="modal" data-target="#requests" id="req"><img src="req.png" id="reqLogo" ><br>View Request</button>
					</div>
					<div class="col">
					  	<button type="button" class="btn btn-lg btn_size" data-toggle="modal" data-target="#inv" id="inv"><img src="inventory.png" id="invLogo" ><br>Inventory</button>
					</div>
					<div class="col">
					</div>
				</div>
				<br>
				<div class="row">
					<div class="col">
					 	<button class="btn btn-lg btn-link btn_size" onclick="window.location.href='blood_banks.html';"><img src="bb.png" id="bbLogo" ><br>Blood Banks</button>
					</div>
					<div class="col">
					  	<button type="button" class="btn btn-lg btn_size" data-toggle="modal" data-target="#trans" id="trans"><img src="his.png" id="hisLogo" ><br>Transaction History</button>
					</div>
					<div class="col">
					</div>
				</div>
			</div>
		</div>
		<script src="https://code.jquery.com/jquery-3.4.1.js" integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script> 
		<script src="remix.js"></script>
		<script>
			function myFunction() {
			  alert("The request was approved successfully!");

			  $("#loader").show();
				<?php
					$array = array();
					$query="SELECT * FROM pending LIMIT 1";
					$result=mysqli_query($con,$query);
					while($row = mysqli_fetch_assoc($result)) { 
						foreach ($row as $col => $val) {
							array_push($array, $val);
						}
						echo "var arr=".json_encode($array).";\n";
				}
				?>
				var arr=<?php echo json_encode($array);?>;
				BloodBank.approveReq(arr[1],arr[2],arr[3],arr[4],arr[5],arr[6],arr[7],arr[8]);
				BloodBank.getCountO_(function(error, result) {
					if (!error) {
						a=result[0];
						b=result[1];
						$("#num_BagsO_").html(''+b);
					} 
					else{
							console.log(error);
					}
					
				});
			}
		</script>
	</body>
</html>